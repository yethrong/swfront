<!-- start: Content -->

<!-- start: Content -->
<div id="content" class="span10">



</div>
<!-- end: Content -->
<div class="modal hide fade" id="myModal">
	<div class="modal-header"> <button type="button" class="close" data-dismiss="modal">×</button> <h3>设置</h3></div>
	<div class="modal-body" id="mySubModal"></div>
	<div class="modal-footer" id="mySubFraml"> <a href="#" class="btn btn-primary">保存</a>  <a href="#" class="btn" data-dismiss="modal">关闭</a> </div>
</div>

<div class="clearfix"></div>
<!-- end: Content -->